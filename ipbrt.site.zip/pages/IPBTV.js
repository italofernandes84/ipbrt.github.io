 <!--<div id="frame_ipbtv">
 	<iframe src="http://www.ipb.org.br/tv/ipbtv1.php" frameborder="0" scrolling="false" width="800" height="600" marginheight="0" marginwidth="0" allowtransparency="false"></iframe>
 </div>-->

<div class="video" align="left"> 
<a href="http://www.ipb.org.br/tv/" target="_blank"><img src="images/ipbtvBanner.png" align="center"/></a>

<script type='text/javascript' 
	src='http://www.internetaovivo.com/ipbtv/jwplayer/jwplayer.js'></script> 
<div id='mediaplayer'></div> 
<script type="text/javascript"> 
	jwplayer('mediaplayer').setup({ 
		'id': 'playerID', 
		'width': '800', 
		'height': '400', 
		'provider': 'rtmp', 
		'streamer': 'rtmp://ec2-174-129-179-185.compute-1.amazonaws.com/live', 
		'levels': [ 
		{ bitrate:"200", width:"480", file:"ipbtv250.sdp" }, 
		{ bitrate:"400", width:"480", file:"ipbtv400.sdp" }, 
		], 
		'image': 'http://www.internetaovivo.com/ipbtv/tela_ipbtv1.jpg',
		'logo.file': 'http://www.internetaovivo.com/ipbtv/ipbtv1_Marcadagua.png', 
		'logo.position': 'top-right', 
		'logo.hide': 'false', 
		'autostart': 'true', 
		'repeat': 'always', 
		'stretching': 'fill', 
		'skin': 'http://www.internetaovivo.com/ipbtv/skin.zip', 
		'plugins': 'fbit-1,tweetit-1',
		'modes': [ 
		{type: 'flash', src: 'http://www.internetaovivo.com/ipbtv/jwplayer/player.swf'}, 
		{ 
		type: 'html5', 
		config: { 
		'file': 'http://ec2-174-129-179-185.compute-1.amazonaws.com:1935/live/smil:ipbtv.smil/playlist.m3u8', 
		'provider': 'video' 
		} 
		} 
		] 
	}); 
</script><br>

<!-- CÓDIGO ENVIADO POR ARTHUR@IPB.ORG.BR EM RESPOSTA A EMAIL ENVIADO.
<embed src='http://www.internetaovivo.com/ipbtv/jwplayer/player.swf' height='400' width='800' bgcolor='0xffff33' allowscriptaccess='always' allowfullscreen='true' flashvars="&autostart=true&backcolor=0xffff33&bandwidth=200&controlbar=over&fbit.height=320&fbit.pluginmode=FLASH&fbit.visible=true&fbit.width=480&fbit.x=0&fbit.y=0&file=ipbtv250.sdp&frontcolor=0xbbbbbb&image=http%3A%2F%2Fwww.internetaovivo.com%2Fipbtv%2Ftela_ipbtv1.jpg&lightcolor=0xff33ff&logo=http%3A%2F%2Fwww.internetaovivo.com%2Fipbtv%2Fipbtv1_Marcadagua.png&plugins=fbit-1h%2Ctweetit-1h%2Cviral-2h&repeat=always&skin=http%3A%2F%2Fwww.internetaovivo.com%2Fipbtv%2Fskin.zip&streamer=rtmp%3A%2F%2Fec2-174-129-179-185.compute-1.amazonaws.com%2Flive&stretching=fill&tweetit.height=320&tweetit.pluginmode=FLASH&tweetit.visible=true&tweetit.width=480&tweetit.x=0&tweetit.y=0&viral.pluginmode=FLASH&logo.file=http://www.internetaovivo.com/ipbtv/ipbtv1_Marcadagua.png"/> -->


<p>Veja todos os canais no site oficial da <a href="http://www.ipb.org.br/tv/">IPBTV clicando aqui</a>.

</p>
</div>
<br><br><br>